#include "controller.h"

Controller::Controller(Model* m, string AB_1, string AB_2) {
    this->model = m;

    if (AB_1.length()>5) throw "AB_1 has too many abilities initalized";
    if (AB_1.length()<5) throw "AB_1 has too little abilities initalized";
    if (AB_2.length()>5) throw "AB_2 has too many abiltiies initalized";
    if (AB_2.length()<5) throw "AB_2 has too little abiltities intialized";

    vector<string> AB_temp;
    AB_temp.emplace_back(AB_1);
    AB_temp.emplace_back(AB_2);

    for(int i=0; i<2; ++i) {
        vector<TypeofAbilities> temp;

        for(int j=0; j<5; ++j) {
            if (AB_temp[i][j]=='F') {
                temp.emplace_back(TypeofAbilities::Firewall);
            } else if (AB_temp[i][j]=='D') {
                temp.emplace_back(TypeofAbilities::Download);
            } else if (AB_temp[i][j]=='S') {
                temp.emplace_back(TypeofAbilities::Scan);
            } else if (AB_temp[i][j]=='P') {
                temp.emplace_back(TypeofAbilities::Polarize);
            } else if (AB_temp[i][j]=='L') {
                temp.emplace_back(TypeofAbilities::LinkBoost);
            } else if (AB_temp[i][j]=='M') {
                temp.emplace_back(TypeofAbilities::Malware);
            } else if (AB_temp[i][j]=='E') {
                temp.emplace_back(TypeofAbilities::Exchange);  
            } else if (AB_temp[i][j]=='I') {
                temp.emplace_back(TypeofAbilities::Invisibility);  
            } else {
                throw "Invalid Controller Setup";
            }
        }

        PlayersAbilities.emplace_back(temp);
    }
}

void Controller::HandleInput(istream &in, ostream& out) {
    string str;
    model->board(out);

    while (getline(in, str)) {
        stringstream s{str};
        string command;
        s >> command;

        if (command=="move") {
            string Link;
            string Dir;

            s >> Link;
            s >> Dir;

            if (s.fail()) {
                cerr << "Incomplete move command." << endl;
                continue;
            }

            if (Owner::P1==model->getTurn()) {
                if (Link.length() > 1 || !((Link>="a")&&(Link<="h"))) {
                    cerr << "Invalid link in move command for Player 1." << endl;
                    continue;
                }
            }

            if (Owner::P2==model->getTurn()) {
                if (Link.length() > 1 || !((Link>="A")&&(Link<="H"))) {
                    cerr << "Invalid link in move command for Player 2." << endl;
                    continue;
                }
            }

            if (!((Dir=="up")||(Dir=="down")||(Dir=="left")||(Dir=="right"))) {
                cerr << "Invalid Dir in move command." << endl;
                continue;
            }

            try {
                model->move(Link, Dir);
                model->board(out);
            } catch (char const *a) {
                cerr << a << endl;
            }

        } else if (command=="abilities") {
            model->displayAbilities(out);
        } else if (command=="ability") {
            int typeAbility;
            s >> typeAbility;

            if (s.fail()) {
                cerr << "Invalid ability command." << endl;
                continue;
            }

            if ((typeAbility<1)||(typeAbility>5)) {
                cerr << "Invalid Ability Id." << endl;
                continue;
            }

            int P_turn;

            if (Owner::P1==model->getTurn()) {
                P_turn=0;
            } else {
                P_turn=1;
            }

            if (PlayersAbilities[P_turn][typeAbility-1]==TypeofAbilities::Firewall) { // check player
                int pos_x, pos_y;

                s >> pos_x;
                s >> pos_y;

                if (s.fail()) {
                    cerr << "Incomplete firewall ability command." << endl;
                    continue;
                }

                try {
                    model->useAbility(typeAbility, Posn{pos_x,pos_y});
                } catch (char const *a) {
                    cerr << a << endl;
                }
            } else if (PlayersAbilities[P_turn][typeAbility-1]==TypeofAbilities::Exchange) {
                string firstLink;
                string secondLink;
                s >> firstLink;
                s >> secondLink;

                if (s.fail()) {
                    cerr << "Invalid Exchange command." << endl;
                    continue;
                }

                if (Owner::P1==model->getTurn()) {
                    if ((!((firstLink>="a")&&(firstLink<="h"))) || (!((secondLink>="a")&&(secondLink<="h")))) {
                        cerr << "Invalid link in Exchange command for Player 1." << endl;
                        continue;
                    }
                }

                if (Owner::P2==model->getTurn()) {
                    if (!((firstLink>="A")&&(firstLink<="H")) || !((secondLink>="A")&&(secondLink<="H"))) {
                        cerr << "Invalid link in Exchange command for Player 2." << endl;
                        continue;
                    }
                }

                try {
                    model->useAbility(typeAbility, firstLink, secondLink);
                } catch (char const *a) {
                    cerr << a << endl;
                }
            } else if (PlayersAbilities[P_turn][typeAbility-1]==TypeofAbilities::Download) {
                string Link;
                s >> Link;

                if (s.fail()) {
                    cerr << "Invalid ability command." << endl;
                    continue;
                }

                if (Owner::P1==model->getTurn()) {
                    if (!((Link>="A")&&(Link<="H"))) {
                        cerr << "Invalid link in Download command for Player 1." << endl;
                        continue;
                    }
                }

                if (Owner::P2==model->getTurn()) {
                    if (!((Link>="a")&&(Link<="h"))) {
                        cerr << "Invalid link in Download command for Player 2." << endl;
                        continue;
                    }
                }
                
                try {
                    model->useAbility(typeAbility, Link);
                } catch (char const *a) {
                    cerr << a << endl;
                } 
            } else if ((PlayersAbilities[P_turn][typeAbility-1]==TypeofAbilities::Scan)||
                        (PlayersAbilities[P_turn][typeAbility-1]==TypeofAbilities::Polarize)) {
                string Link;
                s >> Link;

                if (s.fail()) {
                    cerr << "Invalid ability command" << endl;
                    continue;
                }

                try {
                    model->useAbility(typeAbility, Link);
                } catch (char const *a) {
                    cerr << a << endl;
                }
            } else { // LinkBoost
                string Link;
                s >> Link;

                if (s.fail()) {
                    cerr << "Invalid ability command." << endl;
                    continue;
                }

                if (Owner::P1==model->getTurn()) {
                    if (!((Link>="a")&&(Link<="h"))) {
                        cerr << "Invalid link in ability command for Player 1." << endl;
                        continue;
                    }
                }

                if (Owner::P2==model->getTurn()) {
                    if (!((Link>="A")&&(Link<="H"))) {
                        cerr << "Invalid link in ability command for Player 2." << endl;
                        continue;
                    }
                }

                try {
                    model->useAbility(typeAbility, Link);
                } catch (char const *a) {
                    cerr << a << endl;
                }
            }
        } else if (command=="board") {
            model->board(out);
        } else if (command=="sequence") {
            string FileName;
            s >> FileName;

            if (s.fail()) {
                cerr << "Invalid sequence command." << endl;
                continue;
            }

            ifstream myfile;
            myfile.open(FileName);

            if (myfile.is_open()) {
                HandleInput(myfile, out);            
            }
        
        } else if (command=="quit") {
            break;
        } else {
            cerr << "Invalid Command" << endl;
            continue;
        }
    }
}
