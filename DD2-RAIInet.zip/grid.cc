#include "grid.h"
#include "myLink.h"
#include "owner.h" 


Grid::Grid() {
    for(int i=0; i<8; ++i) {
        vector<Cell> v;
        for(int j=0; j<8; ++j) {
            v.emplace_back(Cell(i, j));
        }
        theGrid.emplace_back(v);
    }

    theGrid[0][3].setServer(Owner::P1);
    theGrid[0][4].setServer(Owner::P1);
    theGrid[7][3].setServer(Owner::P2);
    theGrid[7][4].setServer(Owner::P2);
}

void Grid::attach(MyLink* other, Posn dest) {
    theGrid[dest.row][dest.col].getLink() = other;
}

void Grid::attachObserver(Observer<Notification1> *p, Posn posn) {
    theGrid[posn.row][posn.col].attach(p);
}

void Grid::move(Posn initial, Posn finalPos) {
    auto temp = theGrid[initial.row][initial.col].getLink();

    theGrid[finalPos.row][finalPos.col].place(temp);

    theGrid[initial.row][initial.col].getLink() = nullptr; //deleting link from its original position

    temp->getPosn() = finalPos;
}

Cell& Grid::getCell(Posn posn) {
    return theGrid[posn.row][posn.col];
}

Cell& Grid::getCell(string s) {
    for(int i = 0; i < 8; i++) {
        for(int j = 0; j < 8; j++) {
            if (theGrid[i][j].getLink() != nullptr && theGrid[i][j].getLink()->active && //we should not check the second condition
                theGrid[i][j].getLink()->getname() == s) {
                return theGrid[i][j];
            }
        }
    }

    throw "Link " + s + " is no longer in the board."; 
}

string Grid::display(Owner playerPerspective) {
    string s = "========\n";
    for(int i=0; i < 8; ++i) {
        for(int j=0; j < 8; ++j) {
            s += theGrid[i][j].display(playerPerspective);
        }
        s += "\n";
    }
    s += "========\n";
    return s;
}
