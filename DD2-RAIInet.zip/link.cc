#include "link.h"

Link::Link(LinkType lt, string name, int strength, Owner owner): 
    lt{lt}, name{name}, alias{name}, strength{strength}, owner{owner} {}

LinkType& Link::getLinkType() {
    return lt;
}

string Link::getname() const {
    return name;
}

string& Link::getalias() {
    return alias;
}

int& Link::getstrength() {
    return strength;
}

Owner Link::getOwner() const {
    return owner;
}
