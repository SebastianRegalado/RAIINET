#ifndef OWNER_H
#define OWNER_H
enum class Owner {None, P1, P2};
#endif
