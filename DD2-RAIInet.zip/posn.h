#ifndef POSN_H
#define POSN_H

struct Posn {
    int row, col;
};

#endif
